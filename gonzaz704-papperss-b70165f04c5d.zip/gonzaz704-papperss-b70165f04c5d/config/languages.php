<?php
return [
    'en' => 'English',
    'es' => 'Spanish'
];

<?php

namespace App;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Post extends Model
{

    // Campos que son asignables en masa
    protected $fillable = [
        'title',
        'body',
        'conclusiones',
        'profundizacion',
        'user_id',
    ];
    
    // Castear conclusiones a array
    protected $casts = [
        'conclusiones' => 'array',
    ];

    // Relación uno a muchos inversa con el modelo User
    public function user()
    {
        return $this->belongsTo('App\User');
    }

    // Relación uno a muchos con el modelo PostImage
    public function images()
    {
        return $this->hasMany('App\PostImage');
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Request;
use App\Post;
use App\PostImage;
use Illuminate\Support\Facades\Validator;


class PostsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $posts = Post::orderBy('updated_at', 'desc')->get();
        return view('home', ['posts' => $posts]);
    }

    
    public function create()
    {
        return view('posts.create');
    }

    public function edit(Post $post)
    {
    // Autorización: Verificar si el usuario actual es el autor del post
    $this->authorize('update', $post);


    return view('posts.edit', ['post' => $post]);
    }


    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'title' => 'required|max:255',
            'body' => 'required',
            'conclusiones.*' => 'nullable',
            'profundizacion' => 'required',
        ]);
    
        if ($validator->fails()) {
            return redirect('route-name')
                        ->withErrors($validator)
                        ->withInput();
        }
    
        $conclusiones = array_filter($request->conclusiones, function ($value) {
            return $value !== null && $value !== '';
        });
    
        if (auth()->check()) {
            $post = new Post;
            $post->title = $request->title;
            $post->body = $request->body;
            $post->conclusiones = json_encode($conclusiones);
            $post->profundizacion = $request->profundizacion;
            $post->user_id = auth()->user()->id;
            $post->save();
    
            // Manejar la subida de imágenes después de guardar el post
            if ($request->hasFile('news_images')) {
                $image_comments = $request->image_comments; // Obtén los comentarios de las imágenes
                $image_conclusions = $request->image_conclusions; // Obtén las conclusiones de las imágenes
                foreach ($request->file('news_images') as $index => $file) {
                    $path = $file->store('news_images', 'public');
                    $postImage = new PostImage;
                    $postImage->post_id = $post->id;
                    $postImage->path = $path;
                    $postImage->comment = $image_comments[$index] ?? ''; // Guarda el comentario correspondiente a esta imagen
                    $postImage->conclusiones = $image_conclusions[$index] ?? ''; // Guarda la conclusión correspondiente a esta imagen
                    $postImage->save();
                }
            }
    
            return redirect('/')->with('success', 'Post creado con éxito');
        } else {
            // Redireccionar al usuario a la página de inicio de sesión, o mostrar un error.
            return redirect('login')->with('error', 'Debe iniciar sesión para crear un post.');
        }
    }
    
    public function show($id)
    {
        $post = Post::find($id);

        return view('posts.show', ['post' => $post]);
    }


    public function deleteImage(Post $post, PostImage $image)
{
    $this->authorize('update', $post);

    if ($image->post_id == $post->id) {
        Storage::disk('public')->delete($image->path);
        $image->delete();
    }

    return response()->json(null, 204);
}



    public function update(Request $request, Post $post)
{
    // Autorización: Verificar si el usuario actual es el autor del post
    $this->authorize('update', $post);
    
    // Validación: Puedes ajustar las reglas de validación según tus necesidades
    $validator = Validator::make($request->all(), [
        'title' => 'required|max:255',
        'body' => 'required',
        'conclusiones.*' => 'nullable',
        'profundizacion' => 'required',
        'news_images.*' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
    ]);

    if ($validator->fails()) {
        return redirect()->route('posts.show', $post)
            ->withErrors($validator)
            ->withInput();
    }

    // Aquí es donde defines y utilizas la variable conclusiones
    $conclusiones = array_filter($request->conclusiones, function ($value) {
        return $value !== null && $value !== '';
    });
    
    // Actualizar el post
    $post->title = $request->title;
    $post->body = $request->body;
    $post->conclusiones = json_encode($conclusiones);
    $post->profundizacion = $request->profundizacion;
    $post->user_id = auth()->user()->id;
    $post->save();

    // Borrar las imágenes existentes si es que se solicitó
    if ($request->has('delete_images')) {
        foreach ($request->delete_images as $id) {
            $image = PostImage::findOrFail($id);
            if ($image->post_id == $post->id) {
                // Remover imagen del almacenamiento
                Storage::disk('public')->delete($image->path);
                // Borrar de la base de datos
                $image->delete();
            }
        }
    }

    // Manejar la subida de imágenes después de guardar el post
    if ($request->hasFile('news_images')) {
        $image_comments = $request->image_comments; // Obtén los comentarios de las imágenes
        $image_conclusions = $request->image_conclusions; // Obtén las conclusiones de las imágenes
        foreach ($request->file('news_images') as $index => $file) {
            $path = $file->store('news_images', 'public');
            $postImage = new PostImage;
            $postImage->post_id = $post->id;
            $postImage->path = $path;
            $postImage->comment = $image_comments[$index] ?? ''; // Guarda el comentario correspondiente a esta imagen
            $postImage->conclusiones = $image_conclusions[$index] ?? ''; // Guarda la conclusión correspondiente a esta imagen
            $postImage->save();
        }
    }
    
    // Actualizar los comentarios y las conclusiones de las imágenes existentes
    if ($request->has('image_comments') || $request->has('image_conclusions')) {
        $image_comments = $request->image_comments; // Obtén los comentarios de las imágenes
        $image_conclusions = $request->image_conclusions; // Obtén las conclusiones de las imágenes
        foreach ($post->images as $image) {
            if (array_key_exists($image->id, $image_comments)) {
                $image->comment = $image_comments[$image->id];
            }
            if (array_key_exists($image->id, $image_conclusions)) {
                $image->conclusiones = $image_conclusions[$image->id];
            }
            $image->save();
        }
    }

    // Redirigir al usuario a la página del post con un mensaje de éxito
    return redirect('/')->with('success', 'Post actualizado con éxito');
}

    

}

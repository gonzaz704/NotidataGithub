<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModelTag extends Model
{
    protected $table = "model_has_tags";
}

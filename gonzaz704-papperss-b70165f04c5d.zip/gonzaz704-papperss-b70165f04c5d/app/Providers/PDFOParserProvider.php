<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Library\Services\PDFOParser;

class PDFOParserProvider extends ServiceProvider
{
    /**
     * Bootstrap the application services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }

    /**
     * Register the application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind('App\Library\Services\PDFOParser', function ($app) {
          return new PDFOParser();
        });
    }
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PostImage extends Model
{
    protected $fillable = [
        'post_id',
        'path',
        'comment',
        'conclusiones',
    ];

    protected $casts = [
        'conclusiones' => 'array',
    ];

    public function post()
    {
        return $this->belongsTo('App\Post');
    }
}
